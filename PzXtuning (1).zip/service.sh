#!/system/bin/sh
MODDIR=${0%/*}
CFG=/data/adb/a07_otimizador
LOG=/data/local/tmp/a07_otimizador.log
HIST=/data/local/tmp/a07_ram_historico.log
mkdir -p "$CFG"
[ -f "$CFG/config.conf" ] && . "$CFG/config.conf"
LIMITE_RAM_MB=${LIMITE_RAM_MB:-3072}
LIMPEZA_AUTO=${LIMPEZA_AUTO:-1}
TRIM=${TRIM:-1}
SCAN_OFF=${SCAN_OFF:-1}
LIMPAR_LIXO=${LIMPAR_LIXO:-1}
COMPILAR=${COMPILAR:-1}
PROTECAO_TEMP=${PROTECAO_TEMP:-1}
LIMITE_TEMP=${LIMITE_TEMP:-42}
NOTIFICAR=${NOTIFICAR:-0}
MODO_JOGO=${MODO_JOGO:-0}
AUTO_RESTRINGIR=${AUTO_RESTRINGIR:-0}
AUTO_REPARO=${AUTO_REPARO:-1}
ALTA_PERFORMANCE=${ALTA_PERFORMANCE:-1}
PERF_NIVEL=${PERF_NIVEL:-maximo}
PERF_TEMP_SOC=${PERF_TEMP_SOC:-75}
PERF_CPU_DIR=${PERF_CPU_DIR:-/sys/devices/system/cpu/cpufreq}
PERF_GPU_DIR=${PERF_GPU_DIR:-/sys/class/devfreq}
PERF_STATE="$CFG/perf_state"
PERF_ATIVO=0
PERF_NODES=0
GED_BOOST=${GED_BOOST:-1}
TOUCH_FIXES=${TOUCH_FIXES:-1}
LAUNCH_BOOST=${LAUNCH_BOOST:-1}
REFRESH_HZ=${REFRESH_HZ:-90}
ZRAM_ZSTD=${ZRAM_ZSTD:-1}
RAM_ALVO_PCT=${RAM_ALVO_PCT:-20}
CPUSET_BG=${CPUSET_BG:-1}
[ -f "$MODDIR/props.sh" ] && . "$MODDIR/props.sh"
ECONOMIA_AUTO=${ECONOMIA_AUTO:-1}
ECONOMIA_PCT=${ECONOMIA_PCT:-20}
DND_JOGO=${DND_JOGO:-1}
BENCH_MODE=${BENCH_MODE:-1}
BENCH_TEMP=${BENCH_TEMP:-45}
BENCH_TEMP_SOC=${BENCH_TEMP_SOC:-85}
PERFIL=${PERFIL:-}
case "$PERFIL" in
  economia)    ALTA_PERFORMANCE=0; LAUNCH_BOOST=0; GED_BOOST=0; REFRESH_HZ=60 ;;
  equilibrado) ALTA_PERFORMANCE=1; PERF_NIVEL=equilibrado; LAUNCH_BOOST=1; GED_BOOST=0; REFRESH_HZ=90 ;;
  desempenho)  ALTA_PERFORMANCE=1; PERF_NIVEL=maximo; LAUNCH_BOOST=1; GED_BOOST=1; REFRESH_HZ=90 ;;
  jogo)        ALTA_PERFORMANCE=1; PERF_NIVEL=maximo; LAUNCH_BOOST=1; GED_BOOST=1; REFRESH_HZ=90; MODO_JOGO=1; DND_JOGO=1 ;;
esac
ALTA_CFG=$ALTA_PERFORMANCE
NIVEL_CFG=$PERF_NIVEL
TELA_OFF=0

# espera o boot terminar
while [ "$(getprop sys.boot_completed)" != "1" ]; do sleep 5; done
echo 0 > "$CFG/boot_count"
sleep 30

echo "[$(date)] iniciando ajustes" > "$LOG"
echo "modelo: $(getprop ro.product.model)" >> "$LOG"

RAM_MB=$(awk '/^MemTotal:/ {print int($2/1024)}' /proc/meminfo)
echo "RAM total: ${RAM_MB} MB" >> "$LOG"
if [ "$RAM_MB" -lt 4500 ]; then RA=256; else RA=512; fi

# ================= funcoes =================
ler_lista() { grep -v '^[[:space:]]*#' "$1" 2>/dev/null | tr -d '\r' | awk 'NF {print $1}'; }

salvar_setting() { [ -f "$CFG/backup_$2" ] || settings get "$1" "$2" > "$CFG/backup_$2" 2>/dev/null; }
restaurar_setting() {
  f="$CFG/backup_$2"
  [ -f "$f" ] || return
  v=$(cat "$f")
  if [ -z "$v" ] || [ "$v" = "null" ]; then settings delete "$1" "$2" >/dev/null 2>&1
  else settings put "$1" "$2" "$v"; fi
  rm -f "$f"
}

temp_c() { T=$(cat /sys/class/power_supply/battery/temp 2>/dev/null); echo $(( ${T:-0} / 10 )); }
temp_ok() { [ "$PROTECAO_TEMP" = "1" ] || return 0; [ "$(temp_c)" -lt "$LIMITE_TEMP" ]; }
carregando() { S=$(cat /sys/class/power_supply/battery/status 2>/dev/null); [ "$S" = "Charging" ] || [ "$S" = "Full" ]; }
tela_apagada() { dumpsys power 2>/dev/null | grep -q "mWakefulness=Asleep"; }
notificar() { [ "$NOTIFICAR" = "1" ] || return 0; cmd notification post -t "Otimizador" a07 "$1" >/dev/null 2>&1; }
disp_mb() { awk '/^MemAvailable:/ {print int($2/1024)}' /proc/meminfo; }

limpar_ram() {
  D1=$(disp_mb)
  matar_bg
  sync
  [ -w /proc/sys/vm/drop_caches ] && echo 1 > /proc/sys/vm/drop_caches
  sleep 3
  D2=$(disp_mb)
  LIBERADO=$((D2 - D1))
}

restringir() {
  for p in $(ler_lista "$CFG/apps_restringir.txt"); do
    am set-standby-bucket "$p" restricted >/dev/null 2>&1
  done
}

auto_restringir() {
  [ "$AUTO_RESTRINGIR" = "1" ] || return
  for p in $(pm list packages -3 2>/dev/null | cut -d: -f2 | tr -d '\r'); do
    ler_lista "$CFG/apps_protegidos.txt" | grep -qx "$p" && continue
    B=$(am get-standby-bucket "$p" 2>/dev/null | tr -dc '0-9')
    if [ "$B" = "40" ]; then
      am set-standby-bucket "$p" restricted >/dev/null 2>&1 && echo "auto-restrito: $p" >> "$LOG"
    fi
  done
}

limpar_lixo() {
  [ "$LIMPAR_LIXO" = "1" ] || return
  for d in /data/anr /data/tombstones /data/system/dropbox; do
    [ -d "$d" ] && find "$d" -type f -mtime +2 -delete 2>/dev/null
  done
  echo "[$(date)] lixo antigo removido" >> "$LOG"
}

manutencao_diaria() {
  [ "$TRIM" = "1" ] || return
  AGORA=$(date +%s)
  ULTIMO=$(cat "$CFG/last_trim" 2>/dev/null || echo 0)
  [ $((AGORA - ULTIMO)) -lt 86400 ] && return
  carregando && tela_apagada && temp_ok || return
  limpar_lixo
  if command -v fstrim >/dev/null 2>&1; then
    echo "[$(date)] TRIM: $(fstrim -v /data 2>&1)" >> "$LOG"
  else
    sm idle-maint run >/dev/null 2>&1
    echo "[$(date)] TRIM via idle-maint" >> "$LOG"
  fi
  echo "$AGORA" > "$CFG/last_trim"
}

dexopt_semanal() {
  [ "$COMPILAR" = "1" ] || return
  AGORA=$(date +%s)
  ULTIMO=$(cat "$CFG/last_dexopt" 2>/dev/null || echo 0)
  [ $((AGORA - ULTIMO)) -lt 604800 ] && return
  carregando && tela_apagada && temp_ok || return
  echo "[$(date)] compilacao semanal" >> "$LOG"
  nice -n 19 cmd package bg-dexopt-job >> "$LOG" 2>&1
  echo "$AGORA" > "$CFG/last_dexopt"
}

historico_ram() {
  USO=$(awk '/^MemTotal:/ {t=$2} /^MemAvailable:/ {a=$2} END {print int((t-a)/1024)}' /proc/meminfo)
  echo "$(date +%d/%m\ %H:%M) usado ${USO} MB | temp $(temp_c) C" >> "$HIST"
  if [ "$(wc -l < "$HIST")" -gt 300 ]; then tail -n 200 "$HIST" > "$HIST.tmp" && mv "$HIST.tmp" "$HIST"; fi
}

modo_jogo_check() {
  [ "$MODO_JOGO" = "1" ] || return
  [ -f "$CFG/bench_ativo" ] && return
  JOGOS=$(ler_lista "$CFG/jogos.txt")
  [ -n "$JOGOS" ] || return
  FG=$(dumpsys window 2>/dev/null | grep -m1 mCurrentFocus | sed 's/.* \([^ ]*\)\/.*/\1/')
  if [ -n "$FG" ] && echo "$JOGOS" | grep -qx "$FG"; then
    [ "$FG" = "$ULTIMO_JOGO" ] && return
    ULTIMO_JOGO=$FG
    dnd_on
    limpar_ram
    echo "[$(date)] modo jogo ($FG): liberado ${LIBERADO} MB" >> "$LOG"
    notificar "Modo jogo: liberou ${LIBERADO} MB"
  else
    [ -n "$ULTIMO_JOGO" ] && dnd_off
    ULTIMO_JOGO=""
  fi
}

reparo() { echo "[$(date)] reparo: $1" >> "$LOG"; }

girar_log() {
  for f in "$LOG" "$HIST"; do
    if [ -f "$f" ] && [ "$(wc -c < "$f")" -gt 204800 ]; then
      tail -n 200 "$f" > "$f.tmp" && mv "$f.tmp" "$f"
    fi
  done
}

auto_reparo() {
  [ "$AUTO_REPARO" = "1" ] || return
  girar_log
  aplicar_props
  touch_fixes
  refresh_lock

  # ajustes de memoria que o sistema desfez
  S=$(cat /proc/sys/vm/swappiness 2>/dev/null)
  if [ -n "$S" ] && [ "$S" -lt 100 ] && [ -w /proc/sys/vm/swappiness ]; then
    echo 100 > /proc/sys/vm/swappiness
    reparo "swappiness estava em $S, restaurado para 100"
  fi
  P=$(cat /proc/sys/vm/page-cluster 2>/dev/null)
  if [ -n "$P" ] && [ "$P" != "0" ] && [ -w /proc/sys/vm/page-cluster ]; then
    echo 0 > /proc/sys/vm/page-cluster
    reparo "page-cluster estava em $P, restaurado para 0"
  fi

  # scan em segundo plano que voltou a ligar
  if [ "$SCAN_OFF" = "1" ]; then
    W=$(settings get global wifi_scan_always_enabled 2>/dev/null)
    B=$(settings get global ble_scan_always_enabled 2>/dev/null)
    if [ "$W" != "0" ] || [ "$B" != "0" ]; then
      settings put global wifi_scan_always_enabled 0
      settings put global ble_scan_always_enabled 0
      reparo "scan em segundo plano tinha voltado, desligado de novo"
    fi
  fi

  # apps desativados que o sistema reativou (ex.: apos atualizacao)
  DESAB=$(pm list packages -d 2>/dev/null | tr -d '\r')
  for p in $(ler_lista "$CFG/apps_desativar.txt"); do
    echo "$DESAB" | grep -qx "package:$p" && continue
    pm disable-user --user 0 "$p" >/dev/null 2>&1 && reparo "$p tinha sido reativado, desativado de novo"
  done

  # armazenamento quase cheio
  PCT=$(df /data 2>/dev/null | awk 'NR==2 {gsub("%","",$5); print $5}')
  if [ -n "$PCT" ] && [ "$PCT" -ge 92 ] 2>/dev/null; then
    pm trim-caches 999G >/dev/null 2>&1
    limpar_lixo
    reparo "armazenamento em ${PCT}%, cache e lixo limpos"
    notificar "Armazenamento quase cheio (${PCT}%): cache limpo"
  fi
}

# --- perf inicio ---
temp_max() {
  M=0
  for z in /sys/class/thermal/thermal_zone*/temp; do
    v=$(cat "$z" 2>/dev/null)
    [ -n "$v" ] || continue
    [ "$v" -gt 1000 ] 2>/dev/null && v=$((v / 1000))
    [ "$v" -gt "$M" ] 2>/dev/null && [ "$v" -lt 150 ] && M=$v
  done
  echo "$M"
}

perf_escrever() {
  [ -w "$1" ] || return 1
  grep -q "^$1|" "$PERF_STATE" 2>/dev/null || echo "$1|$(cat "$1")" >> "$PERF_STATE"
  echo "$2" > "$1" 2>/dev/null && PERF_NODES=$((PERF_NODES + 1))
}

perf_restaurar() {
  PERF_ATIVO=0
  [ -f "$PERF_STATE" ] || return
  while IFS='|' read -r f v; do
    [ -w "$f" ] && echo "$v" > "$f" 2>/dev/null
  done < "$PERF_STATE"
  rm -f "$PERF_STATE"
}

perf_aplicar() {
  PERF_NODES=0
  # CPU (Helio G99: policy0 = A55, policy6 = A76)
  for pol in "$PERF_CPU_DIR"/policy*; do
    [ -d "$pol" ] || continue
    MAXF=$(cat "$pol/scaling_max_freq" 2>/dev/null)
    [ -n "$MAXF" ] || continue
    if [ "$PERF_NIVEL" = "maximo" ]; then
      if grep -qw performance "$pol/scaling_available_governors" 2>/dev/null; then
        perf_escrever "$pol/scaling_governor" performance
      else
        perf_escrever "$pol/scaling_min_freq" "$MAXF"
      fi
    else
      perf_escrever "$pol/scaling_min_freq" $((MAXF / 2))
    fi
  done
  # GPU (Mali-G57 via devfreq, quando o kernel expoe)
  for d in "$PERF_GPU_DIR"/*mali* "$PERF_GPU_DIR"/*gpu*; do
    [ -d "$d" ] || continue
    MAXF=$(cat "$d/max_freq" 2>/dev/null)
    [ -n "$MAXF" ] || continue
    if [ "$PERF_NIVEL" = "maximo" ]; then
      if grep -qw performance "$d/available_governors" 2>/dev/null; then
        perf_escrever "$d/governor" performance
      else
        perf_escrever "$d/min_freq" "$MAXF"
      fi
    else
      perf_escrever "$d/min_freq" $((MAXF / 2))
    fi
  done
  # GED (MediaTek): boost de GPU, quando o kernel expoe esses nos
  if [ "$GED_BOOST" = "1" ]; then
    for f in /sys/module/ged/parameters/ged_boost_enable /sys/module/ged/parameters/gx_game_mode /sys/module/ged/parameters/boost_gpu_enable; do
      perf_escrever "$f" 1
    done
  fi
}

perf_check() {
  if [ -f "$CFG/bench_ativo" ]; then
    ALTA_PERFORMANCE=1; PERF_NIVEL=maximo; LT=$BENCH_TEMP; ST=$BENCH_TEMP_SOC
  else
    ALTA_PERFORMANCE=$ALTA_CFG; PERF_NIVEL=$NIVEL_CFG; LT=$LIMITE_TEMP; ST=$PERF_TEMP_SOC
  fi
  if [ "$ALTA_PERFORMANCE" != "1" ]; then
    [ -f "$PERF_STATE" ] && perf_restaurar
    return
  fi
  MOTIVO=""
  TB=$(temp_c)
  BATP=$(cat /sys/class/power_supply/battery/capacity 2>/dev/null)
  if [ "$TELA_OFF" = "1" ]; then MOTIVO="tela apagada"
  elif [ "$TB" -ge "$LT" ]; then MOTIVO="aparelho quente (${TB} C)"
  elif [ "$(temp_max)" -ge "$ST" ]; then MOTIVO="sensores quentes"
  elif [ -f "$CFG/econ_ativa" ] && [ ! -f "$CFG/bench_ativo" ]; then MOTIVO="economia de bateria"
  elif [ "${BATP:-100}" -lt 15 ] && ! carregando; then MOTIVO="bateria baixa"
  elif [ "$PERF_ATIVO" != "1" ] && [ "$TB" -ge $((LT - 3)) ]; then MOTIVO="aguardando esfriar"
  fi
  if [ -n "$MOTIVO" ]; then
    if [ "$PERF_ATIVO" = "1" ]; then
      perf_restaurar
      echo "[$(date)] thermal guard: performance pausada ($MOTIVO)" >> "$LOG"
    fi
  else
    perf_aplicar
    if [ "$PERF_ATIVO" != "1" ]; then
      PERF_ATIVO=1
      echo "[$(date)] alta performance ativa (nivel $PERF_NIVEL, ${PERF_NODES} ajustes CPU/GPU/GED)" >> "$LOG"
      [ "$PERF_NODES" -eq 0 ] && echo "aviso: nenhum no de CPU/GPU aceitou escrita (kernel bloqueou)" >> "$LOG"
    fi
  fi
}
# --- perf fim ---

swap_usado_mb() { awk '/^SwapTotal:/ {t=$2} /^SwapFree:/ {f=$2} END {print int((t-f)/1024)}' /proc/meminfo; }

touch_fixes() {
  if [ "$TOUCH_FIXES" = "1" ]; then
    salvar_setting secure long_press_timeout
    [ "$(settings get secure long_press_timeout 2>/dev/null)" = "300" ] || settings put secure long_press_timeout 300
  else
    restaurar_setting secure long_press_timeout
  fi
}

refresh_lock() {
  [ -f "$CFG/econ_ativa" ] && return
  case "$REFRESH_HZ" in
    ''|0)
      restaurar_setting system min_refresh_rate
      restaurar_setting system peak_refresh_rate
      return ;;
  esac
  if ! dumpsys display 2>/dev/null | grep -Eq "(fps|refreshRate)=${REFRESH_HZ}(\.0)?"; then
    [ -n "$HZ_AVISADO" ] || echo "tela: ${REFRESH_HZ}Hz nao suportado pelo painel, nada alterado" >> "$LOG"
    HZ_AVISADO=1
    return
  fi
  salvar_setting system min_refresh_rate
  salvar_setting system peak_refresh_rate
  for k in min_refresh_rate peak_refresh_rate; do
    if [ "$(settings get system "$k" 2>/dev/null)" != "${REFRESH_HZ}.0" ]; then
      settings put system "$k" "${REFRESH_HZ}.0"
      echo "tela: $k travado em ${REFRESH_HZ}Hz" >> "$LOG"
    fi
  done
}

cpuset_bg() {
  [ "$CPUSET_BG" = "1" ] || return
  LITTLE=$(awk '{print $1 "-" $NF}' "$PERF_CPU_DIR/policy0/related_cpus" 2>/dev/null)
  [ -n "$LITTLE" ] || return
  for f in /dev/cpuset/background/cpus /dev/cpuset/system-background/cpus; do
    [ -w "$f" ] || continue
    CUR=$(cat "$f")
    CURLAST=${CUR##*[-,]}
    LITLAST=${LITTLE##*-}
    # so restringe: nunca expande para mais nucleos
    if [ "$CURLAST" -gt "$LITLAST" ] 2>/dev/null; then
      grep -q "^$f|" "$CFG/cpuset_state" 2>/dev/null || echo "$f|$CUR" >> "$CFG/cpuset_state"
      echo "$LITTLE" > "$f" 2>/dev/null && echo "cpuset: $f = $LITTLE (era $CUR)" >> "$LOG"
    fi
  done
}

zram_zstd() {
  [ "$ZRAM_ZSTD" = "1" ] || return
  Z=/sys/block/zram0
  [ -d "$Z" ] || { echo "zram: zram0 nao encontrado" >> "$LOG"; return; }
  if grep -q "\[zstd\]" "$Z/comp_algorithm" 2>/dev/null; then
    echo "zram: ja usa zstd" >> "$LOG"; return
  fi
  grep -qw zstd "$Z/comp_algorithm" 2>/dev/null || { echo "zram: zstd indisponivel neste kernel" >> "$LOG"; return; }
  USO=$(swap_usado_mb)
  if [ "$USO" -ge 200 ] || [ "$(disp_mb)" -lt 800 ]; then
    echo "zram: troca para zstd adiada (swap em uso ${USO}MB ou pouca RAM livre)" >> "$LOG"; return
  fi
  DISK=$(cat "$Z/disksize")
  PRIO=$(awk '$1=="/dev/block/zram0" {print $5}' /proc/swaps)
  swapoff /dev/block/zram0 2>/dev/null || { echo "zram: swapoff falhou, mantido como estava" >> "$LOG"; return; }
  echo 1 > "$Z/reset"
  echo zstd > "$Z/comp_algorithm"
  [ -w "$Z/max_comp_streams" ] && echo 8 > "$Z/max_comp_streams"
  echo "$DISK" > "$Z/disksize"
  mkswap /dev/block/zram0 >/dev/null 2>&1
  if [ -n "$PRIO" ]; then swapon -p "$PRIO" /dev/block/zram0 2>/dev/null; else swapon /dev/block/zram0 2>/dev/null; fi
  if grep -q "^/dev/block/zram0" /proc/swaps; then
    echo "zram: zstd com 8 streams ativo (${DISK} bytes)" >> "$LOG"
  else
    reparo "zram nao voltou ao swap apos a troca, reinicie para restaurar o padrao"
  fi
}

launch_boost_once() {
  [ "$LAUNCH_BOOST" = "1" ] || return
  [ -f "$CFG/econ_ativa" ] && return
  [ -f "$CFG/bench_ativo" ] && return
  [ "$ALTA_PERFORMANCE" = "1" ] && [ ! -f "$PERF_STATE" ] && return
  [ -f "$PERF_STATE" ] && [ "$PERF_NIVEL" = "maximo" ] && return
  [ "$(temp_c)" -ge "$LIMITE_TEMP" ] && return
  LB=""
  for pol in "$PERF_CPU_DIR"/policy*; do
    [ -w "$pol/scaling_min_freq" ] || continue
    O=$(cat "$pol/scaling_min_freq" 2>/dev/null)
    M=$(cat "$pol/scaling_max_freq" 2>/dev/null)
    [ -n "$O" ] && [ -n "$M" ] || continue
    echo "$M" > "$pol/scaling_min_freq" 2>/dev/null
    LB="$LB $pol|$O"
  done
  sleep 0.8
  for it in $LB; do
    echo "${it#*|}" > "${it%%|*}/scaling_min_freq" 2>/dev/null
  done
}

matar_bg() {
  MANTER=$(ler_lista "$CFG/apps_manter.txt")
  if [ -z "$MANTER" ]; then am kill-all >/dev/null 2>&1; return; fi
  TERC=$(pm list packages -3 2>/dev/null | cut -d: -f2 | tr -d '\r')
  for p in $(ps -A -o NAME 2>/dev/null | tr -d '\r' | sed 's/:.*//' | sort -u); do
    echo "$TERC" | grep -qx "$p" || continue
    echo "$MANTER" | grep -qx "$p" && continue
    am kill "$p" >/dev/null 2>&1
  done
}

parar_apps_tela() {
  for p in $(ler_lista "$CFG/apps_parar_tela.txt"); do
    am force-stop "$p" >/dev/null 2>&1
  done
}

compilar_lista_check() {
  L=$(ler_lista "$CFG/apps_compilar.txt")
  [ -n "$L" ] || return
  CK=$(echo "$L" | cksum | awk '{print $1}')
  [ "$CK" = "$(cat "$CFG/compilar_ck" 2>/dev/null)" ] && return
  carregando && tela_apagada && temp_ok || return
  for p in $L; do
    nice -n 19 cmd package compile -m speed -f "$p" >> "$LOG" 2>&1 && echo "[$(date)] compilado: $p" >> "$LOG"
  done
  echo "$CK" > "$CFG/compilar_ck"
}

economia_check() {
  [ "$ECONOMIA_AUTO" = "1" ] || return
  B=$(cat /sys/class/power_supply/battery/capacity 2>/dev/null)
  if [ "${B:-100}" -lt "$ECONOMIA_PCT" ] && ! carregando; then
    if [ ! -f "$CFG/econ_ativa" ]; then
      touch "$CFG/econ_ativa"
      salvar_setting system min_refresh_rate
      salvar_setting system peak_refresh_rate
      settings put system min_refresh_rate 60.0
      settings put system peak_refresh_rate 60.0
      echo "[$(date)] economia automatica: bateria em ${B}%, tela em 60Hz e extras pausados" >> "$LOG"
    fi
  elif [ -f "$CFG/econ_ativa" ]; then
    rm -f "$CFG/econ_ativa"
    refresh_lock
    echo "[$(date)] economia automatica encerrada" >> "$LOG"
  fi
}

dnd_on() {
  [ "$DND_JOGO" = "1" ] || return
  [ -f "$CFG/zen_antes" ] || settings get global zen_mode > "$CFG/zen_antes" 2>/dev/null
  cmd notification set_dnd priority >/dev/null 2>&1
}

dnd_off() {
  [ -f "$CFG/zen_antes" ] || return
  Z=$(cat "$CFG/zen_antes")
  if [ -z "$Z" ] || [ "$Z" = "0" ] || [ "$Z" = "null" ]; then
    cmd notification set_dnd off >/dev/null 2>&1
  else
    settings put global zen_mode "$Z"
  fi
  rm -f "$CFG/zen_antes"
}

bench_on() {
  date +%s > "$CFG/bench_ativo"
  echo "[$(date)] modo benchmark ativo ($1): performance maxima, limites ${BENCH_TEMP}C/${BENCH_TEMP_SOC}C" >> "$LOG"
  limpar_ram
  ALTA_PERFORMANCE=1; PERF_NIVEL=maximo
  perf_aplicar
}

bench_off() {
  rm -f "$CFG/bench_ativo"
  perf_restaurar
  echo "[$(date)] modo benchmark encerrado ($1)" >> "$LOG"
}

bench_timeout() {
  [ -f "$CFG/bench_ativo" ] || return
  T0=$(cat "$CFG/bench_ativo" 2>/dev/null || echo 0)
  [ $(( $(date +%s) - T0 )) -gt 1200 ] && bench_off "limite de 20 min"
}

bench_evento() {
  if echo "$BENCH_LISTA" | grep -qx "$1"; then
    [ -f "$CFG/bench_ativo" ] || bench_on "$1"
  else
    case "$1" in
      com.android.systemui|*permissioncontroller*|com.google.android.packageinstaller) return ;;
    esac
    [ -f "$CFG/bench_ativo" ] && bench_off "abriu $1"
  fi
}

# acionado por eventos de abertura de app (logcat de eventos), sem polling
launch_boost_loop() {
  ULT=0
  BENCH_LISTA=$(ler_lista "$CFG/benchmarks.txt")
  logcat -b events -v brief -T 1 am_proc_start:I wm_resume_activity:I wm_set_resumed_activity:I '*:S' 2>/dev/null | while read -r _l; do
    AG=$(date +%s)
    if [ "$BENCH_MODE" = "1" ]; then
      case "$_l" in
        *resume*)
          BP=$(echo "${_l#*): }" | grep -o '[a-zA-Z0-9_.]*/' | head -1 | tr -d '/')
          [ -n "$BP" ] && bench_evento "$BP"
          ;;
      esac
    fi
    [ $((AG - ULT)) -lt 2 ] && continue
    ULT=$AG
    launch_boost_once
  done
}

# ================= 1) disco e cache =================
for q in /sys/block/mmcblk*/queue/read_ahead_kb /sys/block/sd*/queue/read_ahead_kb; do
  [ -w "$q" ] && echo "$RA" > "$q" && echo "read_ahead $RA em $q" >> "$LOG"
done
[ -w /proc/sys/vm/vfs_cache_pressure ] && echo 70 > /proc/sys/vm/vfs_cache_pressure

if [ -n "$IO_SCHEDULER" ]; then
  for s in /sys/block/mmcblk*/queue/scheduler /sys/block/sd*/queue/scheduler; do
    if [ -w "$s" ] && grep -q "$IO_SCHEDULER" "$s"; then
      echo "$IO_SCHEDULER" > "$s" && echo "scheduler $IO_SCHEDULER em $s" >> "$LOG"
    fi
  done
fi

# ================= 2) RAM / zram =================
if [ -r /proc/sys/vm/swappiness ] && [ -w /proc/sys/vm/swappiness ]; then
  ATUAL=$(cat /proc/sys/vm/swappiness)
  echo "swappiness atual: $ATUAL" >> "$LOG"
  [ "$ATUAL" -lt 100 ] && echo 100 > /proc/sys/vm/swappiness && echo "swappiness ajustado para 100" >> "$LOG"
fi
[ -w /proc/sys/vm/page-cluster ] && echo 0 > /proc/sys/vm/page-cluster

# ================= 3) scan, logs e DNS =================
if [ "$SCAN_OFF" = "1" ]; then
  salvar_setting global wifi_scan_always_enabled
  salvar_setting global ble_scan_always_enabled
  settings put global wifi_scan_always_enabled 0
  settings put global ble_scan_always_enabled 0
  echo "scan em segundo plano desligado" >> "$LOG"
else
  restaurar_setting global wifi_scan_always_enabled
  restaurar_setting global ble_scan_always_enabled
fi
logcat -G 256K >/dev/null 2>&1

if [ -n "$DNS_PRIVADO" ]; then
  salvar_setting global private_dns_mode
  salvar_setting global private_dns_specifier
  settings put global private_dns_mode hostname
  settings put global private_dns_specifier "$DNS_PRIVADO"
  echo "DNS privado: $DNS_PRIVADO" >> "$LOG"
else
  restaurar_setting global private_dns_mode
  restaurar_setting global private_dns_specifier
fi

# ================= 3b) graficos, toque, tela, cpuset, zram =================
rm -f "$CFG/econ_ativa" "$CFG/bench_ativo"
dnd_off
aplicar_props
touch_fixes
refresh_lock
cpuset_bg
zram_zstd
if [ -w /sys/module/lowmemorykiller/parameters/minfree ]; then
  echo "LMK: modulo legado presente (nao alterado)" >> "$LOG"
else
  echo "LMK: kernel usa lmkd; reforco pela limpeza automatica" >> "$LOG"
fi

# ================= 4) apps =================
if [ -f "$CFG/desativados.txt" ]; then
  for p in $(cat "$CFG/desativados.txt"); do
    ler_lista "$CFG/apps_desativar.txt" | grep -qx "$p" || { pm enable "$p" >/dev/null 2>&1; echo "reativado $p" >> "$LOG"; }
  done
fi
for p in $(ler_lista "$CFG/apps_desativar.txt"); do
  pm disable-user --user 0 "$p" >/dev/null 2>&1 && echo "desativado $p" >> "$LOG"
done
ler_lista "$CFG/apps_desativar.txt" > "$CFG/desativados.txt"
restringir

# ================= 5) cache dos apps =================
pm trim-caches 999G >/dev/null 2>&1
echo "cache dos apps limpo" >> "$LOG"

# ================= 6) rotina em segundo plano =================
LIMITE=$LIMITE_RAM_MB
TETO=$((RAM_MB * 75 / 100))
[ "$TETO" -lt "$LIMITE" ] && LIMITE=$TETO
echo "limpeza automatica acima de ${LIMITE} MB em uso (ligada: $LIMPEZA_AUTO)" >> "$LOG"

rotina_principal() {
  N=0
  ULTIMO_JOGO=""
  TELA_ANT=0
  if tela_apagada; then TELA_OFF=1; else TELA_OFF=0; fi
  perf_restaurar
  perf_check
  while true; do
    sleep 60
    N=$((N + 1))

    if tela_apagada; then TELA_OFF=1; else TELA_OFF=0; fi
    if [ "$TELA_OFF" = "1" ] && [ "$TELA_ANT" = "0" ]; then parar_apps_tela; fi
    TELA_ANT=$TELA_OFF
    bench_timeout
    economia_check

    # leve (todo minuto)
    [ -w /proc/sys/vm/vfs_cache_pressure ] && echo 70 > /proc/sys/vm/vfs_cache_pressure
    for q in /sys/block/mmcblk*/queue/read_ahead_kb /sys/block/sd*/queue/read_ahead_kb; do
      [ -w "$q" ] && echo "$RA" > "$q"
    done
    [ ! -f "$CFG/bench_ativo" ] && [ -w /proc/sys/vm/compact_memory ] && echo 1 > /proc/sys/vm/compact_memory

    modo_jogo_check
    perf_check
    [ $((N % 10)) -eq 0 ] && historico_ram
    [ $((N % 15)) -eq 0 ] && restringir
    [ $((N % 15)) -eq 0 ] && auto_reparo
    if [ $((N % 60)) -eq 0 ]; then
      manutencao_diaria
      dexopt_semanal
      auto_restringir
      compilar_lista_check
    fi

    # pesada (so acima do limite)
    if [ "$LIMPEZA_AUTO" = "1" ] && [ ! -f "$CFG/bench_ativo" ]; then
      USADO=$(awk '/^MemTotal:/ {t=$2} /^MemAvailable:/ {a=$2} END {print int((t-a)/1024)}' /proc/meminfo)
      DISPN=$(disp_mb)
      if [ "$USADO" -ge "$LIMITE" ] || [ "$DISPN" -lt $((RAM_MB * RAM_ALVO_PCT / 100)) ]; then
        limpar_ram
        echo "[$(date)] auto-limpeza: usado ${USADO} MB, liberado ${LIBERADO} MB" >> "$LOG"
        notificar "Limpeza automatica liberou ${LIBERADO} MB"
        sleep 120
      fi
    fi
  done
}

# supervisor: se a rotina parar por algum motivo, reinicia
(
  while true; do
    rotina_principal
    reparo "rotina em segundo plano parou, reiniciando"
    sleep 10
  done
) &

# ================= 6b) app launch boost (por eventos) =================
if [ "$LAUNCH_BOOST" = "1" ] || [ "$BENCH_MODE" = "1" ]; then
  (
    while true; do
      launch_boost_loop
      sleep 30
    done
  ) &
fi

# ================= 7) compilacao inicial (uma vez) =================
FLAG="$CFG/.dex_done"
if [ "$COMPILAR" = "1" ] && [ ! -f "$FLAG" ]; then
  if carregando && temp_ok; then
    echo "[$(date)] compilando apps (pode demorar)" >> "$LOG"
    nice -n 19 cmd package compile -m speed-profile -a >> "$LOG" 2>&1
    touch "$FLAG"
    date +%s > "$CFG/last_dexopt"
    echo "[$(date)] compilacao concluida" >> "$LOG"
  else
    echo "compilacao adiada: carregador ligado e temperatura abaixo de ${LIMITE_TEMP} C" >> "$LOG"
  fi
fi

echo "[$(date)] concluido" >> "$LOG"
