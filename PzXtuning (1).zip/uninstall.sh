#!/system/bin/sh
CFG=/data/adb/a07_otimizador

# restaura configuracoes alteradas pelo modulo (namespace:chave)
for par in global:wifi_scan_always_enabled global:ble_scan_always_enabled global:private_dns_mode global:private_dns_specifier secure:long_press_timeout system:min_refresh_rate system:peak_refresh_rate; do
  ns=${par%%:*}; k=${par#*:}
  f="$CFG/backup_$k"
  if [ -f "$f" ]; then
    v=$(cat "$f")
    if [ -z "$v" ] || [ "$v" = "null" ]; then
      settings delete "$ns" "$k" >/dev/null 2>&1
    else
      settings put "$ns" "$k" "$v"
    fi
  fi
done

# restaura cpuset
if [ -f "$CFG/cpuset_state" ]; then
  while IFS='|' read -r f v; do
    [ -w "$f" ] && echo "$v" > "$f" 2>/dev/null
  done < "$CFG/cpuset_state"
fi

# restaura o Nao perturbe, se ficou ativo por causa do modo jogo
if [ -f "$CFG/zen_antes" ]; then
  Z=$(cat "$CFG/zen_antes")
  if [ -z "$Z" ] || [ "$Z" = "0" ] || [ "$Z" = "null" ]; then cmd notification set_dnd off >/dev/null 2>&1
  else settings put global zen_mode "$Z"; fi
fi

# reativa apps desativados pelo modulo
if [ -f "$CFG/desativados.txt" ]; then
  for p in $(cat "$CFG/desativados.txt"); do pm enable "$p" >/dev/null 2>&1; done
fi

# restaura CPU/GPU se a alta performance estava ativa
if [ -f "$CFG/perf_state" ]; then
  while IFS='|' read -r f v; do
    [ -w "$f" ] && echo "$v" > "$f" 2>/dev/null
  done < "$CFG/perf_state"
fi

rm -rf "$CFG"
rm -f /data/local/tmp/a07_otimizador.log /data/local/tmp/a07_ram_historico.log
