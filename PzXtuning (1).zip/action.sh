#!/system/bin/sh
# Botao de acao do PzXtuning: status completo + limpeza (modo jogo)
# Uso pelo terminal: sh action.sh relatorio   (so mostra o status, sem limpar)

CFG=/data/adb/a07_otimizador
LOG=/data/local/tmp/a07_otimizador.log
[ -f "$CFG/config.conf" ] && . "$CFG/config.conf"
LIMITE_TEMP=${LIMITE_TEMP:-42}
LIMITE_RAM_MB=${LIMITE_RAM_MB:-3072}

OKS=0
AVS=0
ok()    { echo "[OK]     $1"; OKS=$((OKS + 1)); }
aviso() { echo "[AVISO]  $1"; AVS=$((AVS + 1)); }
info()  { echo "         $1"; }

livre() { awk '/^MemFree:/ {print int($2/1024)}' /proc/meminfo; }
disp()  { awk '/^MemAvailable:/ {print int($2/1024)}' /proc/meminfo; }
total() { awk '/^MemTotal:/ {print int($2/1024)}' /proc/meminfo; }
swap_usado() { awk '/^SwapTotal:/ {t=$2} /^SwapFree:/ {f=$2} END {print int((t-f)/1024)}' /proc/meminfo; }
swap_total() { awk '/^SwapTotal:/ {print int($2/1024)}' /proc/meminfo; }
ler_lista() { grep -v '^[[:space:]]*#' "$1" 2>/dev/null | tr -d '\r' | awk 'NF {print $1}'; }
temp_bat() { T=$(cat /sys/class/power_supply/battery/temp 2>/dev/null); echo $(( ${T:-0} / 10 )); }

matar_bg() {
  MANTER=$(ler_lista "$CFG/apps_manter.txt")
  if [ -z "$MANTER" ]; then am kill-all >/dev/null 2>&1; return; fi
  TERC=$(pm list packages -3 2>/dev/null | cut -d: -f2 | tr -d '\r')
  for p in $(ps -A -o NAME 2>/dev/null | tr -d '\r' | sed 's/:.*//' | sort -u); do
    echo "$TERC" | grep -qx "$p" || continue
    echo "$MANTER" | grep -qx "$p" && continue
    am kill "$p" >/dev/null 2>&1
  done
}

BK=/sdcard/Download/PzXGalaxy_backup
if [ "$1" = "restaurar" ]; then
  if [ -d "$BK" ]; then
    cp -f "$BK"/* "$CFG"/ 2>/dev/null && echo "Configuracao restaurada de $BK (reinicie para aplicar)"
  else
    echo "Backup nao encontrado em $BK"
  fi
  exit 0
fi

temp_max() {
  M=0
  for z in /sys/class/thermal/thermal_zone*/temp; do
    v=$(cat "$z" 2>/dev/null)
    [ -n "$v" ] || continue
    [ "$v" -gt 1000 ] 2>/dev/null && v=$((v / 1000))
    [ "$v" -gt "$M" ] 2>/dev/null && [ "$v" -lt 150 ] && M=$v
  done
  echo "$M"
}

top_apps() {
  dumpsys meminfo 2>/dev/null | awk '/Total PSS by process:/ {f=1; next} f && NF==0 {exit} f {print}' | head -5 | sed 's/^ *//; s/ (pid.*//'
}

RAM_MB=$(total)
if [ "$RAM_MB" -lt 4500 ]; then RA_ESP=256; else RA_ESP=512; fi

echo "===== PzXtuning - Status ====="

# ---------- Aparelho ----------
MODELO=$(getprop ro.product.model)
case "$MODELO" in
  SM-A065*|SM-A075*|SM-A155*|SM-A156*|SM-A165*|SM-A166*|SM-A245*|SM-A256*) ok "Modelo compativel: $MODELO" ;;
  *) aviso "Modelo fora da lista: $MODELO (ajustes genericos)" ;;
esac
info "Android $(getprop ro.build.version.release) | $(getprop ro.hardware)"
if [ -f "$LOG" ]; then ok "Modulo executou (log encontrado)"; else aviso "Log nao encontrado (reinicie o aparelho)"; fi

# ---------- RAM ----------
echo "--- RAM ---"
info "RAM livre: $(livre)MB de ${RAM_MB}MB | disponivel: $(disp)MB"
info "Swap/zram usado: $(swap_usado)MB de $(swap_total)MB"
if [ "$(swap_total)" -gt 0 ]; then ok "ZRAM/swap ativo ($(swap_total)MB)"; else aviso "Sem swap/zram ativo"; fi
SWP=$(cat /proc/sys/vm/swappiness 2>/dev/null)
if [ -n "$SWP" ] && [ "$SWP" -ge 100 ]; then ok "swappiness=$SWP"; else aviso "swappiness=${SWP:-?} (esperado 100 ou mais)"; fi
PC=$(cat /proc/sys/vm/page-cluster 2>/dev/null)
if [ "$PC" = "0" ]; then ok "page-cluster=0"; else aviso "page-cluster=${PC:-?} (esperado 0)"; fi
PSI=$(awk '/^some/ {for (i=1;i<=NF;i++) if ($i ~ /^avg10=/) {sub("avg10=","",$i); print $i}}' /proc/pressure/memory 2>/dev/null)
if [ -n "$PSI" ]; then
  info "Pressao de memoria (PSI avg10): $PSI"
  PSI_INT=${PSI%%.*}
  [ "${PSI_INT:-0}" -ge 10 ] && aviso "Pressao de memoria alta" || ok "Pressao de memoria normal"
fi

# ---------- Armazenamento ----------
echo "--- Storage ---"
info "$(df -h /data 2>/dev/null | awk 'NR==2 {print $4 " livres de " $2}')"
for q in /sys/block/mmcblk*/queue/read_ahead_kb /sys/block/sd*/queue/read_ahead_kb; do
  [ -r "$q" ] || continue
  v=$(cat "$q")
  dev=${q#/sys/block/}; dev=${dev%%/*}
  if [ "$v" = "$RA_ESP" ]; then ok "$dev read-ahead=${v}KB"; else aviso "$dev read-ahead=${v}KB (esperado $RA_ESP)"; fi
done
VFS=$(cat /proc/sys/vm/vfs_cache_pressure 2>/dev/null)
if [ "$VFS" = "70" ]; then ok "vfs_cache_pressure=70"; else aviso "vfs_cache_pressure=${VFS:-?} (esperado 70)"; fi
SCHED=$(cat /sys/block/sda/queue/scheduler 2>/dev/null)
[ -n "$SCHED" ] && info "scheduler: $SCHED"

# ---------- Servicos ----------
echo "--- Servicos ---"
if [ "${LIMPEZA_AUTO:-1}" = "1" ]; then
  if ps -A -o ARGS 2>/dev/null | grep -q "[a]07_otimizador/service.sh"; then
    ok "Limpeza automatica ativa (acima de ${LIMITE_RAM_MB}MB)"
  else
    aviso "Limpeza automatica nao encontrada em execucao"
  fi
else
  info "Limpeza automatica desligada no config"
fi
if [ "${SCAN_OFF:-1}" = "1" ]; then
  W=$(settings get global wifi_scan_always_enabled 2>/dev/null)
  B=$(settings get global ble_scan_always_enabled 2>/dev/null)
  if [ "$W" = "0" ] && [ "$B" = "0" ]; then ok "Scan Wi-Fi/Bluetooth em segundo plano desligado"; else aviso "Scan em segundo plano ainda ligado (wifi=$W ble=$B)"; fi
fi
if [ "${AUTO_REPARO:-1}" = "1" ]; then
  RP=$(grep -c "reparo:" "$LOG" 2>/dev/null)
  ok "Auto-reparo ligado (${RP:-0} correcao(oes) ate agora)"
  [ -f "$LOG" ] && grep "reparo:" "$LOG" | tail -2 | sed 's/^\[[^]]*\] //' | while read -r l; do info "$l"; done
else
  info "Auto-reparo desligado no config"
fi
if [ -f "$CFG/last_trim" ]; then
  ok "TRIM diario ja rodou ($(date -d @$(cat "$CFG/last_trim") '+%d/%m %H:%M' 2>/dev/null))"
else
  info "TRIM ainda nao rodou (precisa carregar com a tela apagada)"
fi
if [ -f "$CFG/.dex_done" ]; then ok "Apps compilados (speed-profile)"; else aviso "Compilacao inicial pendente (conecte o carregador e reinicie)"; fi
info "Apps restritos: $(ler_lista "$CFG/apps_restringir.txt" | wc -l) | desativados: $(ler_lista "$CFG/apps_desativar.txt" | wc -l)"
info "Modo jogo: ${MODO_JOGO:-0} | Restringir auto: ${AUTO_RESTRINGIR:-0} | DNS: ${DNS_PRIVADO:-padrao}"

# ---------- Kernel / Bateria ----------
echo "--- CPU / GPU ---"
mhz() { v=$(cat "$1" 2>/dev/null); if [ -n "$v" ]; then echo $((v / $2)); else echo "?"; fi; }
HW=$(getprop ro.hardware)
case "$HW" in
  mt6789*) ok "Chip: Helio G99 (MT6789) | GPU Mali-G57 MC2" ;;
  *) info "Chip: $HW (ajuste generico via cpufreq/devfreq)" ;;
esac
for pol in /sys/devices/system/cpu/cpufreq/policy*; do
  [ -d "$pol" ] || continue
  info "$(basename "$pol"): $(cat "$pol/scaling_governor" 2>/dev/null) | min=$(mhz "$pol/scaling_min_freq" 1000) max=$(mhz "$pol/scaling_max_freq" 1000) atual=$(mhz "$pol/scaling_cur_freq" 1000)MHz"
done
GPU_ACHADA=0
for d in /sys/class/devfreq/*mali* /sys/class/devfreq/*gpu*; do
  [ -d "$d" ] || continue
  GPU_ACHADA=1
  info "GPU $(basename "$d"): $(cat "$d/governor" 2>/dev/null) | min=$(mhz "$d/min_freq" 1000000) max=$(mhz "$d/max_freq" 1000000) atual=$(mhz "$d/cur_freq" 1000000)MHz"
done
[ "$GPU_ACHADA" = "0" ] && info "GPU: devfreq nao exposto neste kernel (controle fica com o sistema)"
if [ "${ALTA_PERFORMANCE:-1}" = "1" ]; then
  if [ -s "$CFG/perf_state" ]; then
    ok "Alta performance ativa (nivel ${PERF_NIVEL:-maximo})"
  else
    aviso "Alta performance pausada (aparelho quente, bateria baixa ou kernel bloqueou)"
  fi
else
  info "Alta performance desligada no config"
fi

echo "--- Graficos / Tela / Toque / RAM ---"
if [ "${GRAFICOS:-1}" = "1" ]; then
  R=$(getprop debug.hwui.renderer)
  if [ -n "$R" ]; then ok "HW Accel: HWUI=$R sf.hw=$(getprop debug.sf.hw) egl.hw=$(getprop debug.egl.hw)"; else aviso "Props de graficos nao aplicadas"; fi
else
  info "Graficos desligado no config"
fi
if [ "${VSYNC_TUNING:-1}" = "1" ]; then
  if [ -n "$(getprop debug.sf.early_phase_offset_ns)" ]; then ok "VSYNC offsets definidos"; else aviso "VSYNC offsets nao aplicados"; fi
fi
HZ=${REFRESH_HZ:-90}
if [ "$HZ" != "0" ]; then
  MR=$(settings get system min_refresh_rate 2>/dev/null)
  if [ "$MR" = "${HZ}.0" ]; then ok "Tela travada em ${HZ}Hz"; else aviso "Tela sem trava de ${HZ}Hz (min_refresh_rate=$MR, o painel pode nao suportar)"; fi
fi
if [ "${GED_BOOST:-1}" = "1" ]; then
  GED=0
  for f in /sys/module/ged/parameters/ged_boost_enable /sys/module/ged/parameters/gx_game_mode /sys/module/ged/parameters/boost_gpu_enable; do
    [ -e "$f" ] && GED=$((GED + 1))
  done
  if [ "$GED" -gt 0 ]; then ok "GED Boost: $GED no(s) do kernel"; else aviso "GED Boost: kernel nao expoe os nos (ignorado)"; fi
fi
if [ "${TOUCH_FIXES:-1}" = "1" ]; then
  if [ "$(settings get secure long_press_timeout 2>/dev/null)" = "300" ]; then ok "Touch fixes (long press 300ms)"; else aviso "Touch fixes nao aplicados"; fi
fi
if [ "${LAUNCH_BOOST:-1}" = "1" ]; then
  if ps -A -o ARGS 2>/dev/null | grep -q "[l]ogcat -b events"; then ok "App Launch Boost ativo (boost de 0,8s ao abrir app)"; else aviso "App Launch Boost nao encontrado em execucao"; fi
fi
ALG=$(sed 's/.*\[\(.*\)\].*/\1/' /sys/block/zram0/comp_algorithm 2>/dev/null)
if [ "$ALG" = "zstd" ]; then ok "ZRAM zstd ativo"; else info "ZRAM: ${ALG:-?} (troca para zstd so no boot, com RAM livre)"; fi
info "Alvo de RAM disponivel: ${RAM_ALVO_PCT:-20}% | cpuset background: $(cat /dev/cpuset/background/cpus 2>/dev/null)"
info "LMK: kernel usa lmkd (reforco pela limpeza automatica)"

echo "--- Perfil / Economia / Benchmark ---"
info "Perfil: ${PERFIL:-manual (config.conf)}"
if [ -f "$CFG/econ_ativa" ]; then aviso "Economia automatica ativa (bateria baixa, tela em 60Hz)"; else info "Economia automatica: aguardando (abaixo de ${ECONOMIA_PCT:-20}%)"; fi
if [ -f "$CFG/bench_ativo" ]; then ok "Modo benchmark ATIVO (limites ${BENCH_TEMP:-45}C/${BENCH_TEMP_SOC:-85}C)"; else info "Modo benchmark: aguardando (abre ao iniciar app de benchmarks.txt)"; fi
info "Apps protegidos da limpeza: $(ler_lista "$CFG/apps_manter.txt" | wc -l) | compilar: $(ler_lista "$CFG/apps_compilar.txt" | wc -l) | parar ao apagar a tela: $(ler_lista "$CFG/apps_parar_tela.txt" | wc -l)"

echo "--- Bateria / Termica ---"
BAT=$(cat /sys/class/power_supply/battery/capacity 2>/dev/null)
ST=$(cat /sys/class/power_supply/battery/status 2>/dev/null)
TB=$(temp_bat)
info "Bateria: ${BAT}% ${ST} | ${TB}C | sensores max: $(temp_max)C"
if [ "$TB" -lt "$LIMITE_TEMP" ]; then ok "Temperatura normal (limite ${LIMITE_TEMP}C)"; else aviso "Aparelho quente (${TB}C), tarefas pesadas adiadas"; fi
info "Ligado ha: $(awk '{print int($1/3600) "h" int(($1%3600)/60) "min"}' /proc/uptime)"

# ---------- Log ----------
echo "--- Log ---"
ERROS=0
[ -f "$LOG" ] && ERROS=$(grep -ci "erro\|error\|inaccessible" "$LOG")
if [ "${ERROS:-0}" -eq 0 ]; then ok "Sem erros no log"; else aviso "$ERROS linha(s) com erro no log ($LOG)"; fi

echo ""
echo "== RAM nas ultimas horas =="
HIST=/data/local/tmp/a07_ram_historico.log
if [ -s "$HIST" ]; then
  tail -n 12 "$HIST" | awk -v tot="$(total)" '{ u=0; for (i=1;i<=NF;i++) if ($i=="usado") u=$(i+1); n=int(u*20/tot); b=""; for (j=0;j<20;j++) b=b (j<n ? "#" : "-"); printf "%s %s [%s] %d MB\n", $1, $2, b, u }'
else
  echo "(sem historico ainda, aparece apos 10 minutos de uso)"
fi

echo ""
echo "== Apps que mais usam RAM =="
top_apps

if [ "$1" = "relatorio" ]; then
  echo ""
  echo "(modo relatorio: nada foi limpo)"
  echo "====================================="
  echo "RESULTADO: $OKS ok, $AVS avisos"
  exit 0
fi

# ---------- Limpeza ----------
L1=$(livre)
D1=$(disp)
echo ""
echo "== Limpando (modo jogo) =="
matar_bg; echo "- Apps em segundo plano encerrados (apps protegidos mantidos)"
pm trim-caches 999G >/dev/null 2>&1 && echo "- Cache dos apps limpo"

if [ "$TB" -ge "$LIMITE_TEMP" ]; then
  echo "- Aparelho quente: TRIM e limpeza de lixo adiados"
else
  for d in /data/anr /data/tombstones /data/system/dropbox; do
    [ -d "$d" ] && find "$d" -type f -mtime +2 -delete 2>/dev/null
  done
  echo "- Lixo antigo removido"
  if command -v fstrim >/dev/null 2>&1; then
    fstrim /data >/dev/null 2>&1 && echo "- TRIM do armazenamento feito"
  fi
fi

for p in $(ler_lista "$CFG/apps_restringir.txt"); do
  am set-standby-bucket "$p" restricted >/dev/null 2>&1
done
echo "- Lista de apps restritos reaplicada"

sync
[ -w /proc/sys/vm/drop_caches ] && echo 1 > /proc/sys/vm/drop_caches && echo "- Cache de arquivos limpo"
[ -w /proc/sys/vm/compact_memory ] && echo 1 > /proc/sys/vm/compact_memory && echo "- Memoria compactada"
sleep 3

echo ""
echo "== Depois =="
echo "RAM: livre $(livre)MB | disponivel $(disp)MB | swap usado $(swap_usado)MB"
echo "RAM liberada: $(( $(livre) - L1 ))MB (disponivel: $(( $(disp) - D1 ))MB)"

echo ""
echo "== Ultimas limpezas automaticas =="
if [ -f "$LOG" ] && grep -q "auto-limpeza\|modo jogo" "$LOG"; then
  grep "auto-limpeza\|modo jogo" "$LOG" | tail -3 | sed 's/^\[[^]]*\] //'
else
  echo "(nenhuma ainda)"
fi

mkdir -p "$BK" 2>/dev/null && cp -f "$CFG"/config.conf "$CFG"/*.txt "$BK"/ 2>/dev/null && echo "Backup da configuracao salvo em $BK"

echo "====================================="
if [ "$AVS" -eq 0 ]; then
  echo "RESULTADO: tudo funcionando ($OKS ok, $AVS avisos)"
else
  echo "RESULTADO: $OKS ok, $AVS avisos (veja acima)"
fi
echo "Obs: o valor liberado varia conforme os apps abertos."
