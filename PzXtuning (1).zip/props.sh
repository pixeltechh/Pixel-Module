# Propriedades de runtime (debug.*): nada e gravado em particoes
setp() {
  if command -v resetprop >/dev/null 2>&1; then
    resetprop "$1" "$2" >/dev/null 2>&1
  else
    setprop "$1" "$2" >/dev/null 2>&1
  fi
}

aplicar_props() {
  # HW Accel: HWUI / Skia / EGL / SurfaceFlinger
  if [ "${GRAFICOS:-1}" = "1" ]; then
    setp debug.hwui.renderer "${HWUI_RENDERER:-skiavk}"
    setp debug.sf.hw 1
    setp debug.egl.hw 1
    setp debug.sf.latch_unsignaled 1
  fi
  # VSYNC tuning (offsets do SurfaceFlinger)
  if [ "${VSYNC_TUNING:-1}" = "1" ]; then
    setp debug.sf.early_phase_offset_ns 500000
    setp debug.sf.early_app_phase_offset_ns 500000
    setp debug.sf.early_gl_phase_offset_ns 1500000
  fi
}
