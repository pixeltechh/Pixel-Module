# Roda na instalacao: detecta o modelo e cria/atualiza os arquivos de configuracao
MODELO=$(getprop ro.product.model)
NOME=""
case "$MODELO" in
  SM-A065*) NOME="Galaxy A06" ;;
  SM-A075*) NOME="Galaxy A07" ;;
  SM-A155*|SM-A156*) NOME="Galaxy A15" ;;
  SM-A165*|SM-A166*) NOME="Galaxy A16" ;;
  SM-A245*) NOME="Galaxy A24" ;;
  SM-A256*) NOME="Galaxy A25" ;;
esac

ui_print "- Modelo detectado: $MODELO"
if [ -n "$NOME" ]; then
  ui_print "- Compativel: $NOME"
else
  ui_print "- Modelo fora da lista (A06/A07/A15/A16/A24/A25)"
  ui_print "- Os ajustes sao genericos, instalando mesmo assim"
fi

CFG=/data/adb/a07_otimizador
mkdir -p "$CFG"

# restaura a configuracao do backup (se for uma instalacao nova)
BK=/sdcard/Download/PzXGalaxy_backup
if [ ! -f "$CFG/config.conf" ] && [ -f "$BK/config.conf" ]; then
  cp -f "$BK"/* "$CFG"/ 2>/dev/null && ui_print "- Configuracao restaurada do backup em $BK"
fi

# ---- config.conf (cria e acrescenta chaves novas sem apagar as suas) ----
[ -f "$CFG/config.conf" ] || cat > "$CFG/config.conf" <<'EOC'
# 1 = ligado, 0 = desligado
EOC
add_cfg() { grep -q "^$1=" "$CFG/config.conf" || echo "$1=$2" >> "$CFG/config.conf"; }
add_cfg LIMITE_RAM_MB 3072      # RAM em uso (MB) que dispara a limpeza automatica
add_cfg IO_SCHEDULER ""         # vazio = nao mexe. Exemplo: mq-deadline
add_cfg LIMPEZA_AUTO 1          # limpeza automatica de RAM
add_cfg TRIM 1                  # TRIM diario + remocao de lixo antigo
add_cfg SCAN_OFF 1              # desliga scan de Wi-Fi/Bluetooth em segundo plano
add_cfg LIMPAR_LIXO 1           # apaga relatorios de erro antigos
add_cfg COMPILAR 1              # compilacao dos apps (inicial e semanal)
add_cfg PROTECAO_TEMP 1         # adia tarefas pesadas se esquentar
add_cfg LIMITE_TEMP 42          # temperatura da bateria (C) para adiar tarefas
add_cfg NOTIFICAR 0             # notificacao apos limpezas (0 = sem notificacoes)
add_cfg MODO_JOGO 0             # limpa a RAM ao abrir um jogo de jogos.txt
add_cfg AUTO_RESTRINGIR 0       # restringe apps que o sistema marcou como sem uso
add_cfg DNS_PRIVADO ""          # vazio = nao mexe. Exemplo: dns.google
add_cfg ALTA_PERFORMANCE 1      # alta performance de CPU/GPU (so com tela ligada e sem esquentar)
add_cfg PERF_NIVEL maximo       # maximo = governor performance | equilibrado = piso de 50%
add_cfg PERF_TEMP_SOC 75        # temperatura dos sensores (C) que pausa a alta performance
add_cfg GRAFICOS 1              # HW Accel: HWUI/Skia/EGL/SurfaceFlinger (props de runtime)
add_cfg HWUI_RENDERER skiavk    # skiavk ou skiagl (use skiagl se notar falhas graficas)
add_cfg VSYNC_TUNING 1          # offsets de VSYNC do SurfaceFlinger
add_cfg GED_BOOST 1             # GED Boost da GPU MediaTek (se o kernel expuser)
add_cfg TOUCH_FIXES 1           # resposta de toque (long press 300 ms)
add_cfg LAUNCH_BOOST 1          # boost de CPU por 0,8 s ao abrir app
add_cfg REFRESH_HZ 90           # trava a taxa de atualizacao (0 = nao mexe)
add_cfg ZRAM_ZSTD 1             # troca o zram para zstd com 8 streams (so no boot e com RAM livre)
add_cfg RAM_ALVO_PCT 20         # mantem pelo menos 20% da RAM disponivel
add_cfg CPUSET_BG 1             # apps em segundo plano ficam nos nucleos pequenos
add_cfg PERFIL ""                # vazio = manual | economia | equilibrado | desempenho | jogo
add_cfg ECONOMIA_AUTO 1         # bateria baixa: tela em 60Hz e extras pausados
add_cfg ECONOMIA_PCT 20         # porcentagem de bateria que ativa a economia
add_cfg DND_JOGO 1              # Nao perturbe enquanto um jogo da lista estiver aberto
add_cfg BENCH_MODE 1            # modo benchmark: performance maxima ao abrir apps de benchmarks.txt
add_cfg BENCH_TEMP 45           # limite da bateria (C) durante o benchmark
add_cfg BENCH_TEMP_SOC 85       # limite dos sensores (C) durante o benchmark
add_cfg AUTO_REPARO 1           # corrige falhas sozinho (ajustes desfeitos, armazenamento cheio, boot)

sed -i 's/^NOTIFICAR=1/NOTIFICAR=0/' "$CFG/config.conf" 2>/dev/null

[ -f "$CFG/apps_restringir.txt" ] || cat > "$CFG/apps_restringir.txt" <<'EOC'
# Um pacote por linha. Apps aqui ficam restritos em segundo plano
# (economiza RAM e bateria, mas podem atrasar notificacoes).
# Exemplo (remova o # para ativar):
# com.facebook.katana
EOC

[ -f "$CFG/apps_protegidos.txt" ] || cat > "$CFG/apps_protegidos.txt" <<'EOC'
# Apps que NUNCA entram na restricao automatica (AUTO_RESTRINGIR)
com.whatsapp
com.whatsapp.w4b
org.telegram.messenger
org.thoughtcrime.securesms
EOC

[ -f "$CFG/jogos.txt" ] || cat > "$CFG/jogos.txt" <<'EOC'
# Pacotes dos jogos para o MODO_JOGO (um por linha).
# Exemplos (remova o # para ativar):
# com.dts.freefireth
# com.tencent.ig
# com.activision.callofduty.shooter
# com.supercell.brawlstars
EOC

[ -f "$CFG/apps_desativar.txt" ] || cat > "$CFG/apps_desativar.txt" <<'EOC'
# Um pacote por linha. Apps aqui sao DESATIVADOS (reversivel).
# Confira o que cada pacote faz antes de ativar.
# Exemplos de bloatware (remova o # para ativar):
# com.facebook.appmanager
# com.facebook.services
# com.facebook.system
EOC
grep -q "diagmonagent" "$CFG/apps_desativar.txt" || cat >> "$CFG/apps_desativar.txt" <<'EOC'
# Telemetria/diagnostico da Samsung (opcional, confira antes):
# com.sec.android.diagmonagent
# com.samsung.android.dqagent
EOC

[ -f "$CFG/apps_manter.txt" ] || cat > "$CFG/apps_manter.txt" <<'EOC'
# Apps que a limpeza de RAM NAO encerra (um pacote por linha).
# Com esta lista preenchida, a limpeza fecha so apps de terceiros fora dela.
com.whatsapp
com.whatsapp.w4b
org.telegram.messenger
com.spotify.music
com.google.android.apps.maps
EOC

[ -f "$CFG/apps_compilar.txt" ] || cat > "$CFG/apps_compilar.txt" <<'EOC'
# Apps que ganham compilacao completa (abrem mais rapido).
# Roda uma vez por alteracao da lista, carregando e com a tela apagada.
# Exemplos (remova o # para ativar):
# com.whatsapp
# com.instagram.android
EOC

[ -f "$CFG/apps_parar_tela.txt" ] || cat > "$CFG/apps_parar_tela.txt" <<'EOC'
# Apps que o modulo forca a parar quando a tela apaga (um pacote por linha).
# Podem atrasar notificacoes desses apps.
# Exemplo (remova o # para ativar):
# com.facebook.katana
EOC

[ -f "$CFG/benchmarks.txt" ] || cat > "$CFG/benchmarks.txt" <<'EOC'
# Apps de benchmark que ativam o modo benchmark (um pacote por linha)
com.antutu.ABenchMark
com.antutu.benchmark.full
com.primatelabs.geekbench6
com.primatelabs.geekbench5
com.futuremark.dmandroid.application
EOC

ui_print "- Configuracoes em $CFG"
