#!/system/bin/sh
# Roda cedo no boot: protecao contra bootloop + props de graficos (antes do SurfaceFlinger)
MODDIR=${0%/*}
CFG=/data/adb/a07_otimizador
mkdir -p "$CFG"
[ -f "$CFG/config.conf" ] && . "$CFG/config.conf"

if [ "${AUTO_REPARO:-1}" = "1" ]; then
  N=$(cat "$CFG/boot_count" 2>/dev/null || echo 0)
  N=$((N + 1))
  echo "$N" > "$CFG/boot_count"
  if [ "$N" -ge 3 ]; then
    touch "$MODDIR/disable"
    echo 0 > "$CFG/boot_count"
    echo "[$(date)] reparo: boot nao concluiu 3 vezes seguidas, modulo desativado por seguranca" >> /data/local/tmp/a07_otimizador.log
    exit 0
  fi
fi

[ -f "$MODDIR/props.sh" ] && . "$MODDIR/props.sh" && aplicar_props
